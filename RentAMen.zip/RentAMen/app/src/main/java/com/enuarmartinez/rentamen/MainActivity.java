package com.enuarmartinez.rentamen;

import android.content.Intent;
import android.content.res.Resources;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    private EditText Email, Password;
    private ListView LV;

    private String Opc[];
    private Intent In;
    private Resources Resources;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Email = (EditText)findViewById(R.id.TxtEmailL);
        Password = (EditText)findViewById(R.id.TxtPw);
        LV = (ListView)findViewById(R.id.LVLogin);
       Resources = this.getResources();
       Opc = Resources.getStringArray(R.array.loginlist);
        ArrayAdapter<String> a = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, Opc);
        LV.setAdapter(a);

        LV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position){
                    case 0:
                        In = new Intent(MainActivity.this, Remenber.class);
                        startActivity(In);
                        break;

                    case 1:
                        In = new Intent(MainActivity.this, Singin.class);
                        startActivity(In);
                        break;
                }
            }
        });



    }
}
